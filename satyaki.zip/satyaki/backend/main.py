from fastapi import FastAPI
from pydantic import BaseModel
import os
from dotenv import load_dotenv
from plugins.web_search import search_web
from llm.local_llm import get_local_response

load_dotenv()
app = FastAPI()

class Prompt(BaseModel):
    message: str

@app.post("/chat")
def chat(prompt: Prompt):
    search_result = search_web(prompt.message)
    full_prompt = f"User: {prompt.message}\n\nWeb Info: {search_result}\n\nAnswer:"
    response = get_local_response(full_prompt)
    return {"response": response}