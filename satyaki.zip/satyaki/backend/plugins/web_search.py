import requests
import os

def search_web(query):
    try:
        SERPAPI_KEY = os.getenv("SERPAPI_KEY")
        url = "https://serpapi.com/search"
        params = {"engine": "google", "q": query, "api_key": SERPAPI_KEY}
        res = requests.get(url, params=params).json()
        return res.get("organic_results", [{}])[0].get("snippet", "No snippet found.")
    except:
        return "No web result available."